package com.capgemini.contactbook.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.informationexception.ContactBookException;

public class ContactBookDaoTest {
	static ContactBookDaoImpl dao;
	static EnquiryBean enquiry;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new ContactBookDaoImpl();
		enquiry = new EnquiryBean();
	}

	@Test
	public void testAddEnquiry() throws ContactBookException {

		assertNotNull(dao.addEnquiry(enquiry));

	}

	/************************************
	 * Test case for addEnquiry()
	 * 
	 ************************************/

	@Ignore
	@Test
	public void testAddAddEnquiry1() throws ContactBookException {
		// increment the number next time you test for positive test case
		assertEquals(1016, dao.addEnquiry(enquiry));
	}

	/************************************
	 * Test case for addEnquiry()
	 * 
	 ************************************/

	@Test
	public void testaddEnquiry2() throws ContactBookException {

		enquiry.setfName("aditya");
		enquiry.setlName("varma");
		enquiry.setContactNo("9874563210");
		enquiry.setpDomain("java");
		enquiry.setpLocation("pune");
		assertTrue("Data Inserted successfully",
				(dao.addEnquiry(enquiry)) > 1000);

	}


	/****************************************************
	 * Test case for getEnquiryDetails()
	 ******************************************************/

	@Test
	public void testGetEnquiryDetails() throws ContactBookException {
		assertNotNull(dao.getEnquiryDetails(1008));
	}

	@Ignore
	@Test
	public void testGetEnquiryDetails1() throws ContactBookException {
		assertEquals("aditya", dao.getEnquiryDetails(1008).getfName());
	}

}
