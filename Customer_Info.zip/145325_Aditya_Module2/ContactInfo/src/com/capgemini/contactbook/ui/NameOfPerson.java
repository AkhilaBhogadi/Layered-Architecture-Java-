package com.capgemini.contactbook.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.informationexception.ContactBookException;
import com.capgemini.contactbook.service.ContactBookService;
import com.capgemini.contactbook.service.ContactBookServiceImpl;

public class NameOfPerson {
	static Scanner sc = new Scanner(System.in);
	static ContactBookService beanService = null;
	static ContactBookServiceImpl beanServiceImpl = null;
	static Logger logger = Logger.getRootLogger();
	public static void main(String[] args) throws ContactBookException {
		PropertyConfigurator.configure("resources//log4j.properties");
		EnquiryBean b1 = null;

		int enqryId = 0;
		int option = 0;
		while(true)
		{
			System.out.println("*******Global Recruitments****");
			System.out.println("1.Enter Enquiry Details ");
			System.out.println("2.View  Enquiry Details");
			
			System.out.println("3.Exit");
			System.out.println("________________________________");
			System.out.println("Please enter a choice:");

				option = sc.nextInt();

				switch (option) {
				case 1:
					
					while (b1 == null) {
						b1 = populateEnquiryBean();
						// System.out.println(donorBean);
					}
					
					try {
						beanService = new ContactBookServiceImpl();
						enqryId = beanService.addEnquiry(b1);

						System.out
								.println("Thank you "+b1.getfName()+" "+b1.getlName()+" Your unique id is"+enqryId );
						

					} catch (Exception e) {
						
						e.printStackTrace();
						
					} finally {
						enqryId = 0;
						beanService = null;
						b1 = null;
					}

					break;
				case 2:
					
					beanServiceImpl = new ContactBookServiceImpl();

					System.out.println("Enter numeric donor id:");
					enqryId = sc.nextInt();


			      b1 = beanServiceImpl.getEnquiryDetails(enqryId);

					if (b1 != null) {
						System.out.println("Name      :"
								+ b1.getfName());
						System.out.println("last       :"
								+ b1.getlName());
						System.out.println("Phone Number     :"
								+ b1.getContactNo());
						System.out.println("location      :"
								+ b1.getpLocation());
						System.out.println("Domain :"
								+ b1.getpDomain());
						
					} else {
						System.err
								.println("There are no donation details associated with donor id "
										+ enqryId);
					}

					break;	
				case 3:
					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}// end
				}
	}
	public static EnquiryBean populateEnquiryBean()
	{
	EnquiryBean b= new EnquiryBean();
	
	System.out.println("\n Enter Details");

	System.out.println("Enter first name: ");
     b.setfName(sc.next());
    

	System.out.println("Enter last name: ");
	 b.setlName(sc.next());

	System.out.println("Enter contact number: ");
	b.setContactNo(sc.next());
	System.out.println("Enter location: ");
	b.setpLocation(sc.next());
	System.out.println("Enter domain: ");
	b.setpDomain(sc.next());
	beanServiceImpl=new ContactBookServiceImpl();
	try {
		beanServiceImpl.isValidEnquiry(b);
		return b;
		} catch (ContactBookException donorException) {
		logger.error("exception occured", donorException);
		System.err.println("Invalid data:");
		System.err.println(donorException.getMessage() + " \n Try again..");
		System.exit(0);

	}
	return null;
	}
}

