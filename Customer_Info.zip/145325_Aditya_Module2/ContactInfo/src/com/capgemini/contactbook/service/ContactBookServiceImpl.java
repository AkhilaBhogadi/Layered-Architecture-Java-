package com.capgemini.contactbook.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;









import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.informationexception.ContactBookException;

public class ContactBookServiceImpl implements ContactBookService{
	ContactBookDao dao;
	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		dao=new ContactBookDaoImpl();	
		int beanSeq;
		beanSeq= dao.addEnquiry(enqry);
		return beanSeq; 
	}

	
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException {
		dao=new ContactBookDaoImpl();
		EnquiryBean bean=null;
		bean=dao.getEnquiryDetails(EnquiryID);
		return bean;
	}


	public void isValidEnquiry(EnquiryBean enqry) throws ContactBookException {
		
		List<String> validationErrors = new ArrayList<String>();
		

		//Validating first name
		if(!(isValidFirstName(enqry.getfName()))) {
			validationErrors.add("\n First Name Should Be In Alphabets and minimum 3 characters long ! \n");
			
		}
		//Validating last name
		if(!(isValidLastName(enqry.getlName()))) {
			validationErrors.add("\nLast Name Should Be In Alphabets and minimum 3 characters long ! \n");
			
		}
	
		//Validating Phone Number
		if(!(isValidPhoneNumber(enqry.getContactNo()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
			
		}
		//Validating Domain Name
		if(!(isValidDomain(enqry.getpDomain()))) {
			validationErrors.add("\n domain Name Should Be In Alphabets and minimum 3 characters long ! \n");
			
		}
		
		
		if(!validationErrors.isEmpty())
			throw new ContactBookException(validationErrors +"");

		
	}
	
	public boolean isValidFirstName(String donorName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(donorName);
		return nameMatcher.matches();
	}
	public boolean isValidLastName(String donorName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(donorName);
		return nameMatcher.matches();
	}
	
	
	public boolean isValidPhoneNumber(String string){
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		String number = String.valueOf(string);
		Matcher phoneMatcher=phonePattern.matcher(number);
		return phoneMatcher.matches();
		
	}
	
	
	public boolean isValidDomain(String domain){
		try{
		if(domain==null)
		{
			throw new ContactBookException(domain); 
		}
		
		else
		{
			return true;
		}
		}
		catch(ContactBookException g)
		{
			System.out.println("Domain should not be null");
			return false;
		}
		
	}
	

}
