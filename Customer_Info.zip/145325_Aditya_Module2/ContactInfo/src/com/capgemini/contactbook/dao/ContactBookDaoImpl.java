package com.capgemini.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.contactbook.bean.EnquiryBean;
import com.capgemini.contactbook.informationexception.ContactBookException;
import com.capgemini.contactbook.utility.DBConnection;

public class ContactBookDaoImpl implements ContactBookDao{
	Logger logger=Logger.getRootLogger();
	public ContactBookDaoImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
	int enqryId=0;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QMapper.INSERT_QUERY);

			preparedStatement.setString(1,enqry.getfName());			
			preparedStatement.setString(2,enqry.getlName());
			preparedStatement.setString  (3,enqry.getContactNo());
			preparedStatement.setString(4,enqry.getpLocation());	
			preparedStatement.setString(5,enqry.getpDomain());	
		
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QMapper.APPLYID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				enqryId=resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new ContactBookException("Inserting apply details failed ");

			}
			else
			{
				logger.info("apply details added successfully:");
				return enqryId;
			}

		}
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			throw new ContactBookException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new ContactBookException("Error in closing db connection");

			}
		}
		

	}

	@Override
	public EnquiryBean getEnquiryDetails(int EnquiryID) throws ContactBookException {
Connection connection=DBConnection.getInstance().getConnection();
		
		
		PreparedStatement preparedStatement=null;
		ResultSet resultset = null;
		EnquiryBean b=null;
		
		try
		{
			preparedStatement=connection.prepareStatement(QMapper.VIEW_BEAN_QUERY);
			preparedStatement.setInt(1,EnquiryID);
			resultset=preparedStatement.executeQuery();
			
			if(resultset.next())
			{
				b = new EnquiryBean();
				
				b.setfName(resultset.getString(1));
				b.setlName(resultset.getString(2));
				b.setContactNo(resultset.getString(3));
				b.setpLocation(resultset.getString(4));
				b.setpDomain(resultset.getString(5));
				
				
			}
			
			if( b != null)
			{
				logger.info("Record Found Successfully");
				return b;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
			
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			throw new ContactBookException(e.getMessage());
		}
		finally
		{
			try 
			{
				resultset.close();
				preparedStatement.close();
				connection.close();
			} 
			catch (SQLException e) 
			{
				logger.error(e.getMessage());
				throw new ContactBookException("Error in closing db connection");

			}
		}
	}
	}


