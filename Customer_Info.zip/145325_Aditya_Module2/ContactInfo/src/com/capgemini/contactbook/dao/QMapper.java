package com.capgemini.contactbook.dao;

public interface QMapper {
	public static final String VIEW_BEAN_QUERY="SELECT firstName,lastName ,contactNo ,domain ,city  FROM enquiry WHERE  enqryId =?";
	public static final String INSERT_QUERY="INSERT INTO enquiry VALUES(enquiries.NEXTVAL,?,?,?,?,?)";
	public static final String APPLYID_QUERY_SEQUENCE="SELECT enquiries.CURRVAL FROM DUAL";
	

}
