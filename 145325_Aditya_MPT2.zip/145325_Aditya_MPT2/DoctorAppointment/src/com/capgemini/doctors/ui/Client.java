package com.capgemini.doctors.ui;
 
import java.sql.SQLException;
import java.util.Scanner;
 
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;
 
public class Client {
 
	public static void main(String[] args) throws SQLException {
		IDoctorAppointmentService pat=new DoctorAppointmentService();
		DoctorAppointment d1=new DoctorAppointment();
		int ch;
		do{
			System.out.println("---------------------------------------------------");
		System.out.println("Enter your choice \n1. Book Doctor Appointment\n2. View Doctor Appointment\n3. Exit");
		Scanner scan =new Scanner(System.in);
		ch=scan.nextInt();
		switch (ch) {
		case 1:
			pat.addDoctorAppointmentDetails(d1);
			System.out.println("\n\n**Appointment Date and time, along with doctor�s phone number will be shared shortly with you.");
			break;
		case 2:
			System.out.println("Enter Appointment ID :");
			int input1=scan.nextInt();
			pat.getDoctorAppointmentDetails(input1);
			break;
		case 3:
			System.out.println("Thank You :");
			System.exit(1);
			break;
		default:
			break;
		}}while(ch!=3);
	}
 
}