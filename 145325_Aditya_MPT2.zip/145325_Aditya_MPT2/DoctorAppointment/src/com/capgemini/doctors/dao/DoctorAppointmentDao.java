package com.capgemini.doctors.dao;
 
 
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
 
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
 
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.helper.ConnectToDB;
 
public class DoctorAppointmentDao implements IDoctorAppointmentDao{
	private Connection con=null;
	private PreparedStatement prep=null;
	private ResultSet res=null;
 
	private PreparedStatement prep1=null;
	private ResultSet res1=null;
 
	static Logger logger=Logger.getLogger(DoctorAppointmentDao.class);
 
 
 
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment docApp) throws SQLException {
		int i = 0;
		String Appointment_ID = null;
		try {
			con=ConnectToDB.createConnection();
			prep=con.prepareStatement("insert into doctor_appointment values(seq_appointment_id.nextval,?,?,sysdate+1,?,?,?,?,?,?)");
			prep1=con.prepareStatement("Select appointment_id from doctor_appointment ");
 
 
				prep.setString(1, docApp.getPat_name());
				prep.setString(2, docApp.getPhoneno());
				prep.setString(3, docApp.getEmail());
				prep.setInt(4, docApp.getAge());
				prep.setString(5, docApp.getGender());
				prep.setString(6, docApp.getProblem_name());
				prep.setString(7, docApp.getDoctor_name());
 
				if(docApp.getAppoint_status()){
				prep.setString(8, "APPROVED");
				}
				else
				prep.setString(8, "DISAPPROVED");
 
				i=prep.executeUpdate();
				res1=prep1.executeQuery();
				while(res1.next()) {
					Appointment_ID=res1.getString(1);
				}
				System.out.println("\nYour Doctor Appointment has been successfully registered, your appointment ID is : "+Appointment_ID);
				String log4jConfigFile=System.getProperty("user.dir")+File.separator+"log4j.properties";
				PropertyConfigurator.configure(log4jConfigFile);
				logger.info("Inserted Details");
 
 
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			con.close();
		}
		return i;
	}
	@Override
	public DoctorAppointment getAppointmentDetails(int appoint_Id) throws ClassNotFoundException, SQLException {
		DoctorAppointment d1=new DoctorAppointment();
		Boolean a=false;
		con=ConnectToDB.createConnection();
		prep=con.prepareStatement("select * from doctor_appointment where appointment_id=?");
		prep1=con.prepareStatement("Select appointment_id from doctor_appointment");
		prep.setInt(1, appoint_Id);
		res=prep.executeQuery();
		res1=prep1.executeQuery();
		while(res1.next())
		{   
			int i=res1.getInt(1);
			if(appoint_Id==i){
				 a=true;
				while(res.next()){
					d1.setPat_name(res.getString(2) );
					d1.setDoctor_name(res.getString(9));
					System.out.println("Patient Name: "+ res.getString(2) +"\nAppointment Status  :"+res.getString(10)+"\nDoctor Name:"+res.getString(9));
					String s=res.getString(10);
					System.out.println(s);
					if(s=="DISAPPROVED")
						d1.setAppoint_status(false);
					else
						d1.setAppoint_status(true);
				}
		}
		}
		if(!a){System.out.println("Enter valid Appointment ID");}
		String log4jConfigFile=System.getProperty("user.dir")+File.separator+"log4j.properties";
		PropertyConfigurator.configure(log4jConfigFile);
		logger.info("details  Viewed ");
		return d1;
	}
}