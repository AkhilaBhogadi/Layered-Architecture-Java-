package com.capgemini.doctors.dao;
 
 
import static org.junit.Assert.*;
 
import java.sql.SQLException;
 
import org.junit.Test;
 
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.service.DoctorAppointmentService;
 
public class DoctorAppointmentDaoTest {
 
	DoctorAppointment doc_App = new DoctorAppointment();
	DoctorAppointmentDao d=new DoctorAppointmentDao();
	@Test
	public void addDoctorAppointmentDetailstest() throws SQLException {
		assertEquals("Error",1,d.addDoctorAppointmentDetails(doc_App) );
	}
	@Test
	public void getAppointmentDetailstest() throws ClassNotFoundException, SQLException {
		doc_App=d.getAppointmentDetails(1003);
		System.out.println(doc_App.getAppoint_status());
		if(doc_App.getAppoint_status())
		assertEquals("Error", "Patient Name: abcd \nAppointment Status  :APPROVED \nDoctor Name:Dr.Kanika Kap","Patient Name: "+doc_App.getPat_name()+" \nAppointment Status  :APPROVED"+" \nDoctor Name:"+doc_App.getDoctor_name());
		else
		assertEquals("Error", "Patient Name: abcd \nAppointment Status  :DISAPPROVED \nDoctor Name:Dr.Kanika Kap","Patient Name: "+doc_App.getPat_name()+"\nAppointment Status  :DISAPPROVED  \nDoctor Name:"+doc_App.getDoctor_name());
 
	}
 
}
