package com.capgemini.doctors.dao;
 
 import java.sql.SQLException;
 
import com.capgemini.doctors.bean.DoctorAppointment;
 
public interface IDoctorAppointmentDao {
	int addDoctorAppointmentDetails(DoctorAppointment docApp) throws SQLException;
	DoctorAppointment getAppointmentDetails(int appoint_Id) throws ClassNotFoundException, SQLException;
}
