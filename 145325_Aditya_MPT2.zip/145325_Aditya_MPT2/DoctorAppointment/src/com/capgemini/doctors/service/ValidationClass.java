package com.capgemini.doctors.service;
 
 
 
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
 
import com.capgemini.doctors.bean.DoctorAppointment;
 
public class ValidationClass {
	Scanner scan=new Scanner(System.in);
	void checkEmail(DoctorAppointment d_app){
		 String EMAIL_PATTERN ="^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		 Matcher m ;
		 do
			{
			System.out.print("Enter mail ID : ");
			String email = scan.nextLine();
			Pattern p = Pattern.compile(EMAIL_PATTERN);
			m = p.matcher(email);
				if(!m.find())
				{
					System.out.println("Enter Valid Mail Id");
				}
				else
				{   d_app.setEmail(email);
					break;
				}
			}while(!m.find());
	}
	void checkPhoneNo(DoctorAppointment d){
		Matcher m;
		do
		{
		System.out.println("Enter  phone number : ");
		String phoneNo = scan.nextLine();
		Pattern p = Pattern.compile("[6789][0-9]{9}");
		m = p.matcher(phoneNo);
			if(!m.find())
			{
				System.out.println("Valid value should contain 10 digits exactly.");
			}
			else
			{	d.setPhoneno(phoneNo);
				break;
			}
		}while(!m.find());
	}
	void checkName(DoctorAppointment d){
		Matcher m;
		do
		{
		System.out.println("Enter patient name : ");
		String name = scan.nextLine();
		Pattern p = Pattern.compile("^[A-Z a-z]+$");
		m = p.matcher(name);
			if(!m.find())
			{
				System.out.println("Enter correct name\n");
			}
			else
			{	
				d.setPat_name(name);
				break;
			}
		}while(!m.find());
		}
 
	public void checkgender(DoctorAppointment doc_App) {
		Matcher m;
		do
		{
		System.out.print("Enter Gender(male|female) :");
		String gen = scan.nextLine();
		Pattern p = Pattern.compile("[f F]*{0,1}[e E]*{0,1}male$");
		m = p.matcher(gen);
			if(!m.find())
			{
				System.out.println("Enter correct gender");
			}
			else
			{	
				doc_App.setGender(gen);
				break;
			}
		}while(!m.find());
	}
}
 