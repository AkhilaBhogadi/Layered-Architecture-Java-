package com.capgemini.doctors.service;
 
 
import java.sql.SQLException;
import java.util.Scanner;
 
import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
 
public class DoctorAppointmentService implements IDoctorAppointmentService {
	ValidationClass v=new ValidationClass();
 
	DoctorAppointmentDao dao=new DoctorAppointmentDao();
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doc_App) throws SQLException {
		Scanner scan=new Scanner(System.in);
		v.checkName(doc_App);
		v.checkPhoneNo(doc_App);
		v.checkEmail(doc_App);
		System.out.print("Enter Age     :");
		doc_App.setAge(scan.nextInt());
		v.checkgender(doc_App);
		System.out.print("Enter Problem name :");
		String prob=scan.next();
		doc_App.setProblem_name(prob);
 
		switch (prob) {
		case "Heart":
			 doc_App.setDoctor_name("Dr. Brijesh ");
			 doc_App.setAppoint_status(true);
			break;
		case "Gynecology":
			 doc_App.setDoctor_name("Dr. Sharada ");
			 doc_App.setAppoint_status(true);
			break;
		case "Diabetes":
			 doc_App.setDoctor_name("Dr. Heena  ");
			 doc_App.setAppoint_status(true);
			break;
		case "ENT":
			 doc_App.setDoctor_name("Dr. Paras M");
			 doc_App.setAppoint_status(true);
			 break;
		case "Bone":
			 doc_App.setDoctor_name("Dr.Renuka  ");
			 doc_App.setAppoint_status(true);
			break;
		case "Dermatology":
			 doc_App.setDoctor_name("Dr.Kanika Kap");
			 doc_App.setAppoint_status(true);
			break;
		default:
			doc_App.setDoctor_name(null);
			doc_App.setAppoint_status(false);
		}
 
 
		int a=dao.addDoctorAppointmentDetails(doc_App);
		return a;
	}
 
	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int app_id) {
		DoctorAppointment d = null;
		try {
			 d=dao.getAppointmentDetails(app_id);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return d;
	}
 
}