package com.capgemini.doctors.service;
 
 
import java.sql.SQLException;
 
import com.capgemini.doctors.bean.DoctorAppointment;
 
public interface IDoctorAppointmentService {
	int addDoctorAppointmentDetails(DoctorAppointment doc_App) throws SQLException;
	DoctorAppointment getDoctorAppointmentDetails(int app_id) ;
}
