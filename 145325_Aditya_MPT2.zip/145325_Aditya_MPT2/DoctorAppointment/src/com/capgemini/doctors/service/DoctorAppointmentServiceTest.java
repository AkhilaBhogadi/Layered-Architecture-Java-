package com.capgemini.doctors.service;
 
import static org.junit.Assert.*;
 
import java.sql.SQLException;
 
import org.junit.Test;
 
import com.capgemini.doctors.bean.DoctorAppointment;
 
public class DoctorAppointmentServiceTest {
 
	DoctorAppointment doc_App = new DoctorAppointment();
	DoctorAppointmentService d=new DoctorAppointmentService();
/*	@Test
	public void test() throws SQLException {
		assertEquals("Error",1,d.addDoctorAppointmentDetails(doc_App) );
	}*/
	@Test
	public void test1() {
		doc_App=d.getDoctorAppointmentDetails(1003);
		System.out.println(doc_App.getAppoint_status());
		if(doc_App.getAppoint_status())
		assertEquals("Error", "Patient Name: abcd \nAppointment Status  :APPROVED \nDoctor Name:Dr.Kanika Kap","Patient Name: "+doc_App.getPat_name()+" \nAppointment Status  :APPROVED"+" \nDoctor Name:"+doc_App.getDoctor_name());
		else
		assertEquals("Error", "Patient Name: abcd \nAppointment Status  :DISAPPROVED \nDoctor Name:Dr.Kanika Kap","Patient Name: "+doc_App.getPat_name()+"\nAppointment Status  :DISAPPROVED  \nDoctor Name:"+doc_App.getDoctor_name());
	} 
}