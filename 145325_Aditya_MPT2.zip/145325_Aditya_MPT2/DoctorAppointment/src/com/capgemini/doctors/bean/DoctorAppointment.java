package com.capgemini.doctors.bean;
 
public class DoctorAppointment {
	
	private int appointment_id;
	private String patient_name;
	private String phoneno;
	private String gender;
	private String date_of_appointment;
	private String email;
	private int age;
	private String problem_name;
	private String doctor_name=null;
	private Boolean appointment_status=false;
 
	@Override
	public String toString() {
		return "Patient Name: " + patient_name + " Doctor Name:"
				+ doctor_name  ;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDate_of_app() {
		return date_of_appointment;
	}
	public void setDate_of_app(String date_of_app) {
		this.date_of_appointment = date_of_app;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
 
	public int getAppointment_id() {
		return appointment_id;
	}
	public void setAppointment_id(int appointment_id) {
		this.appointment_id = appointment_id;
	}
	public String getPat_name() {
		return patient_name;
	}
	public void setPat_name(String pat_name) {
		this.patient_name = pat_name;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
 
	public String getProblem_name() {
		return problem_name;
	}
	public void setProblem_name(String problem_name) {
		this.problem_name = problem_name;
	}
	public String getDoctor_name() {
		return doctor_name;
	}
	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}
	public Boolean getAppoint_status() {
		return appointment_status;
	}
	public void setAppoint_status(Boolean appoint_status) {
		this.appointment_status = appoint_status;
	}
}


