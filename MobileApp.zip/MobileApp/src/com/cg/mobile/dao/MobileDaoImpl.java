package com.cg.mobile.dao;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.cg.mobile.bean.Mobile;

public class MobileDaoImpl implements IMobileDao {
	
@Override
public String display(){
	return "demo";
}
@Override
public List<Mobile> getMobileByPrice(double price){
	try{
   	 
	    Class.forName("oracle.jdbc.driver.OracleDriver");

		String url = "jdbc:oracle:thin:@localhost:1521:XE";

		Connection conn = DriverManager.getConnection (url, "system", "Capgemini123");

		System.out.println("connected");
		String sql = "select * from mobiles where price >=?";
		

		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setDouble(1, price);

		ResultSet rs=ps.executeQuery();
		Mobile m =  null;
		
List<Mobile> list = new ArrayList();
		while(rs.next()){
		m = new Mobile();	
         m.setMobileid(rs.getInt(1));
         m.setName(rs.getString(2));
         m.setPrice(rs.getDouble(3));
         m.setQuantity(rs.getString(4));
         list.add(m);
         //	System.out.println("Emo No = "+rs.getInt("empno"));

		//System.out.println("Emo Name = "+rs.getString("ename"));

		}
		return list;
	}
	   catch(Exception e){
	    }
	return null;
	
}
@Override
public List<Mobile> getAllMobiles(){
	try{
   	 
	    Class.forName("oracle.jdbc.driver.OracleDriver");
String url = "jdbc:oracle:thin:@localhost:1521:XE";
Connection conn = DriverManager.getConnection (url, "system", "Capgemini123");
System.out.println("connected");
String sql = "select * from mobiles";
		PreparedStatement ps=conn.prepareStatement(sql);
		//ps.setDouble(1, price);
ResultSet rs=ps.executeQuery();
Mobile m =  null;
List<Mobile> list = new ArrayList();
		while(rs.next()){
		m = new Mobile();	
         m.setMobileid(rs.getInt(1));
         m.setName(rs.getString(2));
         m.setPrice(rs.getDouble(3));
         m.setQuantity(rs.getString(4));
         list.add(m);
         //	System.out.println("Emo No = "+rs.getInt("empno"));

		//System.out.println("Emo Name = "+rs.getString("ename"));

		}
		return list;
	}
	   catch(Exception e){
	    }
return null;
}
}
