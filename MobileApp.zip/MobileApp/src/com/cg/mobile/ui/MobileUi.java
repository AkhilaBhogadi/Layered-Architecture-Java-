package com.cg.mobile.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.mobile.bean.Mobile;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.MobileServiceImpl;

public class MobileUi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		IMobileService service = new MobileServiceImpl();
		System.out.println(service.display());
		Scanner sc = new Scanner(System.in);
		while(true) {
			System.out.println("1. Insert");
			System.out.println("2. Update");
			System.out.println("3. View");
			System.out.println("4. Delete");
			System.out.println("5. Search");
			System.out.println("6. Exit");
			System.out.println("Enter your option");
			int option = sc.nextInt();
			switch(option){
			case 1:break;
			case 2:break;
			case 3:
				List<Mobile> list1= service.getAllMobiles();
				for(Mobile m:list1){
					System.out.println("------------------------------");
					System.out.println("id:"+m.getMobileid());
					System.out.println("name:"+m.getName());
					System.out.println("price:"+m.getPrice());
					System.out.println("quantity:"+m.getQuantity());
					}
					break;
			case 4:break;
			case 5:
				System.out.println("enter price");
				double price = sc.nextDouble();
			List<Mobile> list= service.getMobileByPrice(2000);
			for(Mobile m:list){
				System.out.println("--------------------------------");
			System.out.println("id:"+m.getMobileid());
			System.out.println("name:"+m.getName());
			System.out.println("price:"+m.getPrice());
			System.out.println("quantity:"+m.getQuantity());
			}
			break;
			case 6:
				System.out.println("Thank You");
				break;
			default:System.out.println("invalid option");
			}
			
		}
		/*List<Mobile> list= service.getMobileById(2000);
		for(Mobile m:list){
		System.out.println("id:"+m.getMobileid());
		System.out.println("name:"+m.getName());
		System.out.println("price:"+m.getPrice());
		System.out.println("quantity:"+m.getQuantity());
		}*/

	}

}
                   